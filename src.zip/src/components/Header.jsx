import logoImg from "../assets/logo.jpg";
import Button from "../UI/Button.jsx";
import CartContext from "../store/CartContext.jsx";
import { useContext } from "react";
import UserProgressContext from "../store/progressContext.jsx";

const Header = () => {
  const cartCtx = useContext(CartContext);
  const userCtx = useContext(UserProgressContext);

  // console.log(cartCtx.items);

  function handleShowCart() {
    userCtx.showCart();
  }

  const totalCartItems = cartCtx.items.reduce((totalNumberOfItems, item) => {
    return totalNumberOfItems + item.quantity;
  }, 0);
  return (
    <>
      <header id="main-header">
        <div id="title">
          <img src={logoImg} alt="A Hotel" />
          <h1>Hunger</h1>
        </div>
        <nav>
          <Button textOnly onClick={handleShowCart}>
            Cart({totalCartItems})
          </Button>
        </nav>
      </header>
    </>
  );
};
export default Header;
