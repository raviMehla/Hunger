import Modal from "../UI/Modal.jsx";
import { useContext, useState } from "react";
import CartContext from "../store/CartContext";
import { currencyFormat } from "../util/currencyFormat";
import Input from "../UI/Input.jsx";
import Button from "../UI/Button.jsx";
import UserProgressContext from "../store/progressContext.jsx";

const Checkout = () => {
  const cartCtx = useContext(CartContext);
  const userCtx = useContext(UserProgressContext);
  const [isSubmitted, setIsSubmitted] = useState(false); // New state for submission status

  const cartTotal = cartCtx.items.reduce(
    (totalPrice, item) => totalPrice + item.quantity * item.price,
    0
  );

  function handleCloseCheckout() {
    userCtx.hideCheckout();
  }

  async function handleSubmit(event) {
    event.preventDefault();

    const dataFromForm = new FormData(event.target);
    const customerData = Object.fromEntries(dataFromForm.entries());

    console.log("Customer data is :", customerData);

    await fetch("http://localhost:3000/orders", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        order: {
          items: cartCtx.items,
          customer: customerData,
        },
      }),
    });

    setIsSubmitted(true);
    cartCtx.clearCart();
  }

  return (
    <Modal open={userCtx.progress === "checkout"} onClose={handleCloseCheckout}>
      {isSubmitted ? (
        <div>
          <h2>Order Submitted</h2>
          <p>Our Delivery Team will reach you soon with your order</p>
          <p className="modal-actions">
            <Button type="button" textOnly onClick={handleCloseCheckout}>
              Close
            </Button>
          </p>
        </div>
      ) : (
        <form action="" onSubmit={handleSubmit}>
          <h2>CheckOut</h2>
          <p>Total Amount : {currencyFormat.format(cartTotal)}</p>

          <Input label="Full Name" type="text" id="name" name="name" />
          <Input label="Email Address" type="email" id="email" name="email" />

          <Input label="Street" type="text" id="street" name="street" />
          <div className="control-row">
            <Input
              label="Postal Code"
              type="text"
              id="postal-code"
              name="postal-code"
            />
            <Input label="City" type="text" id="city" name="city" />
          </div>

          <p className="modal-actions">
            <Button type="button" textOnly onClick={handleCloseCheckout}>
              Close
            </Button>
            <Button textOnly>Submit Order</Button>
          </p>
        </form>
      )}
    </Modal>
  );
};

export default Checkout;
