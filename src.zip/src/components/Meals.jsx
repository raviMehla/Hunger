import MealItem from "./MealItem";
import useHttp from "../Hooks/useHTTP.js";

const requestConfig = {};

const Meals = () => {
  const {
    success: loadedData,
    loading,
    error,
  } = useHttp("http://localhost:3000/meals", requestConfig, []);

  if (loading) {
    return <p className="centre">Fetching meals....</p>;
  }

  if (!loadedData) {
    return <p className="centre">Nothing found...</p>;
  }

  return (
    <>
      <ul id="meals">
        {loadedData.map((meal) => (
          <MealItem key={meal.id} meal={meal} />
        ))}
      </ul>
    </>
  );
};
export default Meals;
