import { useCallback, useEffect, useState } from "react";

async function sendHttpRequest(url, config) {
  const response = await fetch(url, config);

  const resData = await response.json();

  if (!response.ok) {
    throw new Error(
      resData.message || "Something went wrong in backend"
    );
  }

  return resData;
}

const useHttp = (url, config, initialData) => {

  const [error, setError] = useState(initialData);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState();

  const sendRequest = useCallback(async function sendRequest() {
    setLoading(true)
    try {
      const resData = await sendHttpRequest(url, config);
      setSuccess(resData);
    }
    catch (error) {
      setError(error.message || "Something went wrong with backend")
    }
    setLoading(false)
  }, [url, config]);

  useEffect(() => {

    if (config && (config.method === "GET" || !config.method) || !config)
      sendRequest();
  }, [sendRequest, config])

  return {
    success,
    loading,
    error,
    sendRequest
  }

}
export default useHttp;